# Pokemon NXT MMO — World Startup Fix 1.1.2

Apply this to your **existing configured Server folder**. No rebuild, MySQL reconfiguration or database reset is needed.

1. Extract this entire ZIP into a folder.
2. If an NXT world server is running, type `shutdown` in its console first.
3. Double-click **APPLY_WORLD_STARTUP_FIX.cmd**. Paste your existing **Server** folder path and press Enter. You can also drag that Server folder onto the CMD file.
4. Run **3 - Start World Server.cmd** inside that same Server folder.

The patch corrects world ownership startup handling and ensures startup failures are logged. A running world still prevents a second world from using the same database.

Only `server.py`, `nxt/store.py` and `3 - Start World Server.cmd` are replaced. Your `config.ini`, installed Python environment, accounts, saves, assets and EXEs are preserved. Previous scripts are backed up under `Server/backups/world_startup_fix_*`; applying the patch again is safe.

The patch result is in **world_startup_fix.log** beside this README. Startup can wait up to 65 seconds for an abandoned database lease to expire, then continues automatically. A lease that is still being refreshed is not overridden. If world startup still fails, keep the console open and check the cause and full log path it displays.
