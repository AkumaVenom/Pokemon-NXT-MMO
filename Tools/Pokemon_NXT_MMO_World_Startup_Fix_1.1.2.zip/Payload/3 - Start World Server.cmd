@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Pokemon NXT MMO - World Server
if not exist ".venv\Scripts\python.exe" (
 echo Run 1 - Install Server Dependencies.cmd first.
 pause
 exit /b 1
)
echo Starting Pokemon NXT MMO world server...
echo Startup diagnostics will show the full log path below.
echo.
".venv\Scripts\python.exe" -u server.py --config "%~dp0config.ini"
set "NXT_WORLD_RESULT=%ERRORLEVEL%"
if not "%NXT_WORLD_RESULT%"=="0" (
 echo.
 echo World server exited with an error. Read the cause and log path above.
 echo If another NXT world is running, shut it down before restarting this one.
 pause
 exit /b %NXT_WORLD_RESULT%
)
echo World stopped cleanly.
pause
exit /b 0
