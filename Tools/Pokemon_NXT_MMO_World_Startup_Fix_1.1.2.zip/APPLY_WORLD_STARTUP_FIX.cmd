@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Pokemon NXT MMO - World Startup Fix 1.1.2
echo Pokemon NXT MMO - World Startup Fix 1.1.2
echo.
echo Stop any running NXT world server with its shutdown command first.
echo This installs three fixed scripts. No rebuild or database setup is needed.
echo.
set "NXT_PATCH_TARGET=%~1"
if defined NXT_PATCH_TARGET goto normalize_target
set /p "NXT_PATCH_TARGET=Paste your existing configured Server folder path, then press Enter: "
:normalize_target
if not defined NXT_PATCH_TARGET goto cancelled
set "NXT_PATCH_TARGET=%NXT_PATCH_TARGET:"=%"
if not defined NXT_PATCH_TARGET goto cancelled
for %%I in ("%NXT_PATCH_TARGET%\.") do set "NXT_PATCH_TARGET=%%~fI"
if exist "%NXT_PATCH_TARGET%\Server\server.py" set "NXT_PATCH_TARGET=%NXT_PATCH_TARGET%\Server"
if not exist "%NXT_PATCH_TARGET%\server.py" goto wrong_folder
if not exist "%NXT_PATCH_TARGET%\.venv\Scripts\python.exe" goto missing_python
if not exist "%~dp0apply_fix.py" goto missing_payload
if not exist "%~dp0Payload\SHA256.json" goto missing_payload
set "NXT_PATCH_LOG=%~dp0world_startup_fix.log"
>"%NXT_PATCH_LOG%" echo Pokemon NXT MMO - World Startup Fix 1.1.2
if errorlevel 1 goto log_failed
"%NXT_PATCH_TARGET%\.venv\Scripts\python.exe" "%~dp0apply_fix.py" --target "%NXT_PATCH_TARGET%" >>"%NXT_PATCH_LOG%" 2>&1
set "NXT_PATCH_EXIT=%ERRORLEVEL%"
type "%NXT_PATCH_LOG%"
echo.
echo Patch log: "%NXT_PATCH_LOG%"
if not "%NXT_PATCH_EXIT%"=="0" goto patch_failed
echo.
echo You can now run 3 - Start World Server.cmd in your existing Server folder.
pause
exit /b 0
:patch_failed
echo.
echo The fix did not complete. Read the error above and the patch log.
pause
exit /b %NXT_PATCH_EXIT%
:wrong_folder
echo.
echo That folder does not contain server.py. Select your configured Server folder.
goto failed
:missing_python
echo.
echo The selected Server folder has no installed Python environment.
echo Choose the Server folder where you already completed server setup.
echo Expected: "%NXT_PATCH_TARGET%\.venv\Scripts\python.exe"
goto failed
:missing_payload
echo.
echo Extract the entire hotfix ZIP first, then run this CMD from the extracted folder.
goto failed
:log_failed
echo.
echo Cannot create the patch log. Extract this hotfix into a writable folder and retry.
goto failed
:cancelled
echo.
echo Cancelled. No project files were changed.
:failed
pause
exit /b 1
